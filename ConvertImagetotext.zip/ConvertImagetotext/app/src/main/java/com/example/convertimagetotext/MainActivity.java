package com.example.convertimagetotext;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;


import com.google.android.gms.cast.framework.media.ImagePicker;

public class MainActivity extends AppCompatActivity {
    ImageView clear,copy,camera;
    EditText recotext;
    Uri imageuri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        clear=findViewById(R.id.imageView);
        copy=findViewById(R.id.imageView2);
        camera=findViewById(R.id.imageView4);
        recotext=findViewById(R.id.editTextText);
        openccamera();

    }

    private void openccamera() {
        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImagePicker.with(this)
                        .crop()	    			//Crop image(Optional), Check Customization for more option
                        .compress(1024)			//Final image size will be less than 1 MB(Optional)
                        .maxResultSize(1080, 1080)	//Final image resolution will be less than 1080 x 1080(Optional)
                        .start();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode== Activity.RESULT_OK){
            if(data!=null){
                imageuri=data.getData();
            }

        }
        else {
            Toast.makeText(this,"image not select",Toast.LENGTH_LONG);
        }
    }
}